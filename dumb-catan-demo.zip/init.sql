CREATE DATABASE IF NOT EXISTS catanv2;
USE catanv2;


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` char(60) NOT NULL,
  `avatarURL` varchar(5) NOT NULL,
  `activeGames` int NOT NULL,
  `role` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `games`;

CREATE TABLE `games` (
  `gameId` int NOT NULL AUTO_INCREMENT,
  `owner` varchar(20) NOT NULL,
  `tileOrder` mediumtext NOT NULL,
  `diceIdOrder` mediumtext NOT NULL,
  `devCards` mediumtext NOT NULL,
  `robberLocation` varchar(10) DEFAULT NULL,
  `longestRoad` int NOT NULL,
  `largestArmy` int NOT NULL,
  `longestRoadHolder` varchar(20) DEFAULT NULL,
  `largestArmyHolder` varchar(20) DEFAULT NULL,
  `playerList` mediumtext NOT NULL,
  PRIMARY KEY (`gameId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `nodes`;

CREATE TABLE `nodes` (
  `nodeId` int NOT NULL AUTO_INCREMENT,
  `nodeNumber` int NOT NULL,
  `gameId` int NOT NULL,
  `structure` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`nodeId`),
  KEY `fk_nodes_game_id` (`gameId`),
  CONSTRAINT `fk_nodes_game_id` FOREIGN KEY (`gameId`) REFERENCES `games` (`gameId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `roads`;

CREATE TABLE `roads` (
  `roadId` int NOT NULL AUTO_INCREMENT,
  `roadNumber` int NOT NULL,
  `gameId` int NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`roadId`),
  KEY `fk_roads_game_id` (`gameId`),
  CONSTRAINT `fk_roads_game_id` FOREIGN KEY (`gameId`) REFERENCES `games` (`gameId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `players`;

CREATE TABLE `players` (
  `playerId` int NOT NULL AUTO_INCREMENT,
  `armySize` int NOT NULL,
  `playableDevCards` mediumtext NOT NULL,
  `points` int NOT NULL,
  `resourceCards` mediumtext NOT NULL,
  `startingNodes` varchar(10) NOT NULL,
  `unplayableDevCards` mediumtext NOT NULL,
  `gameId` int NOT NULL,
  `userId` int NOT NULL,
  `color` varchar(10) NOT NULL,
  PRIMARY KEY (`playerId`),
  KEY `fk_players_game_id` (`gameId`),
  KEY `fk_players_user_id` (`userId`),
  CONSTRAINT `fk_players_game_id` FOREIGN KEY (`gameId`) REFERENCES `games` (`gameId`) ON DELETE CASCADE,
  CONSTRAINT `fk_players_user_id` FOREIGN KEY (`userId`) REFERENCES `users` (`userID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `invites`;
CREATE TABLE `invites` (
  `inviteId` int NOT NULL AUTO_INCREMENT,
  `gameId` int NOT NULL,
  `userId` int NOT NULL,
  PRIMARY KEY (`inviteId`),
  KEY `fk_invites_game_id` (`gameId`),
  KEY `fk_invites_user_id` (`userId`),
  CONSTRAINT `fk_invites_game_id` FOREIGN KEY (`gameId`) REFERENCES `games` (`gameId`) ON DELETE CASCADE,
  CONSTRAINT `fk_invites_user_id` FOREIGN KEY (`userId`) REFERENCES `users` (`userId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;